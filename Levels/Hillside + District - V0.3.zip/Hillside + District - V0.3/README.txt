HILLSIDE + DISTRICT CAMPAIGN
        VERSION 0.3
         BY Raven "Edgewurth" Penfold
============================

Installation -
		Please place the files with the name Hillside in the /Levels/ folder in the CorsixTH Root Folder (often C:\Program Files\CorsixTH\). It should automatically then detect the level data.

Note -
		This is a pre-release version. There will be issues. If you do find any, please direct message "raven_edgewurth" on Discord, detailing what you've done and the campaign version.

		There currently is no campaign data at present. This is because only the first level area is complete. Please see the Levels Section for a list.

Levels -
		01: Markoville
		02: Greenfort
		03: Silverdale
		04: Old Hillside (DONE)
		05: Crossways
		06: Turing
		07: Ham-On-Trent
		08: Hillside Central

Changelog -
		0.3
			- Updated the License to CC By-4.0
			- Replaced any Deadnames
			- Corrected the Level Win Message
		0.2
			- Made Winning Conditions more reasonable
			- Made Starting Balance higher by $20000 to match land value.
			- Increased time between hiring capability
		0.1
			- Fixed the Window issue by changing to single/double windows.
		0.0
			- Inital Release